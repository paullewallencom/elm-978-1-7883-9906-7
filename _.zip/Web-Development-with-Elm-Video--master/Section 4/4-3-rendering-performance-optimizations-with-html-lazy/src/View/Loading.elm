module View.Loading exposing (view)

import Html exposing (Html, text)


view : Html msg
view =
    text "Loading..."
