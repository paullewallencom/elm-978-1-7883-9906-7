# Encapsulation and Code Organization

How to organize the structure of a bigger project. Using Union types to encapsulate sensitive state.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
