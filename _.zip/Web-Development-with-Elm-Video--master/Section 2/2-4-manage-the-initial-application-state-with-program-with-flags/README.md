# Manage the initial application state with Program with Flags

Initialization parameters for your application.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
