# Talking to JavaScript

Communicate with the JavaScript runtime through Port modules. Integrating JavaScript logic with Elm application.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
