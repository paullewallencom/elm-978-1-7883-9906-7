# Introducing Side effects with Beginner program

Handling user-input in the application with Messages.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
