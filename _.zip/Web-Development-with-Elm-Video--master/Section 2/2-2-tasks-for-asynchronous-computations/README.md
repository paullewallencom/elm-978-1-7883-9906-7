# Tasks for asynchronous computations

Describing asynchronous operations, that might fail as data.
