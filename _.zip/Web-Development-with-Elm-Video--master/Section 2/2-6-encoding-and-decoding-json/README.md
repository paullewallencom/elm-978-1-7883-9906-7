# Encoding and Decoding JSON

Converting Elm Data types and Data structures to JSON with Json.Encode.
Ensuring type safety with runtime type guards using Json.Decode.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
