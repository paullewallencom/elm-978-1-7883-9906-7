# Starting-up with your first Elm App

The contents are covered in [Create Elm App: Getting Started](https://github.com/halfzebra/create-elm-app#getting-started)