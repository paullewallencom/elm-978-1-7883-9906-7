# Expressing the Model with Built-in Data types

Expressing the Model of your application with the built-in primitive Data types such as Tuples and Records.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
