# Persistent data structures in Elm

Using built-in Data structures List, Arrays, Dictionaries and Sets in your application.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
