# Maybe and the Result data types

Describe errors as data with Result and the absence of data with Maybe.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
