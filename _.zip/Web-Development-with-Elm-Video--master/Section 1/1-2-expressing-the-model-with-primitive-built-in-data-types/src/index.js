import { Main } from './Main.elm';

Main.embed(document.getElementById('root'));
