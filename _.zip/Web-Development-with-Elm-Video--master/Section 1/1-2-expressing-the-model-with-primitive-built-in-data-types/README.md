# Expressing the Model with primitive built-in Data types

Learn the very basics of Elm, such as value and function declaration, partial application and basic operators.
