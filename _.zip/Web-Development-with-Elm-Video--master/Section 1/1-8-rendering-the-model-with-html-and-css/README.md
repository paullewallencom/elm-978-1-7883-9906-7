# Rendering the Model with HTML and CSS

Implementing a View for HTML representation of your application Model with Html module.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
