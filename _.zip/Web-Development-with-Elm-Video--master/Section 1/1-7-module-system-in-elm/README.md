# Module system in Elm

Elm’s module system, module declaration syntax. Defining your first module.

This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
