module Util exposing ((=>))


(=>) : a -> b -> ( a, b )
(=>) =
    (,)
