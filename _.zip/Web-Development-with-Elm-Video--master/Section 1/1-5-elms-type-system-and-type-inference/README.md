# Expressing the Model with Built-in Data types

How to read and define type annotations. Introduction to the concept of Type aliases and Union types for more expressive Model.

- Type aliases
- Union types


This project is bootstrapped with [Create Elm App.](https://github.com/halfzebra/create-elm-app)
