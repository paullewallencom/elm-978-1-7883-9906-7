# Development tools: elm-format, Time Traveling Debugger and elm-reactor

The essential tooling for frictionless development experience. Automatic formatting for consistent code style with elm-format. Using the debugger and elm-reactor.

Make sure to install [elm-format](https://github.com/avh4/elm-format#editor-integration) for your editor.

In Create Elm App elm-reactor is available with `elm-app reactor` command.
